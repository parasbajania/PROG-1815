﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PbajaniaAssignment1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
                
            Button b =(Button)sender;
            listBox2.Text = listBox2.Text + b.Text;

            
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button20_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "0")
            {
                listBox1.Items.Add(this.textBox1.Text);
                this.textBox1.Focus();
                this.textBox1.Clear();
            }
            else
            {
                MessageBox.Show("Please enter a name to add", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.textBox1.Focus();
            }
            
        }

        private void button21_Click(object sender, EventArgs e)
        {
            if(this.listBox1.SelectedIndex >=0)
            {
                this.listBox1.Items.RemoveAt(this.listBox1.SelectedIndex);
            }
        }

        private void button22_Click(object sender, EventArgs e)
        { 
            richTextBox2.Text = textBox1.Text;
        }

        private void button16_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add(richTextBox1.Text);
        }

        private void button19_Click(object sender, EventArgs e)
        {
             if (textBox2.Text=="0")
             {
                richTextBox1.Text = textBox2.ToString();
             }
             else
             {
                MessageBox.Show("plz enter your name for checking aviablitiy of seat");
             }
           
        }
    }
}
